const fs = require('fs');
const path = require('path');

const filesToPatch = [
    path.join(__dirname, 'node_modules', '@angular-devkit', 'build-angular', 'src', 'webpack', 'configs', 'dev-server.js'),
    path.join(__dirname, 'node_modules', '@angular-devkit', 'build-angular', 'src', 'utils', 'webpack-dev-server.js')
];

console.log('🔧 Correction du problème "Invalid Host Header"...');

function patchFile(filePath) {
    if (!fs.existsSync(filePath)) {
        console.log(`⚠️ Fichier non trouvé: ${filePath}`);
        return false;
    }

    try {
        let content = fs.readFileSync(filePath, 'utf8');
        
        if (content.includes('disableHostCheck')) {
            content = content.replace(/disableHostCheck:\s*false/g, 'disableHostCheck: true');
            console.log(`✅ Paramètre disableHostCheck corrigé dans ${filePath}`);
        } 
        else {
            content = content.replace(/devServer\s*:\s*{/g, 'devServer: {\n      disableHostCheck: true,');
            console.log(`✅ Paramètre disableHostCheck ajouté dans ${filePath}`);
        }
        
        fs.writeFileSync(filePath, content, 'utf8');
        return true;
    } catch (error) {
        console.error(`❌ Erreur lors du patch de ${filePath}:`, error);
        return false;
    }
}

let patchedAny = false;
for (const file of filesToPatch) {
    if (patchFile(file)) {
        patchedAny = true;
    }
}

if (patchedAny) {
    console.log('\n✅ Correction terminée! Le problème "Invalid Host Header" devrait être résolu.');
    console.log('🔄 Redémarrez votre application frontend pour appliquer les changements.');
} else {
    console.log('\n⚠️ Aucun fichier n\'a pu être patché. Essayez la méthode manuelle:');
    console.log('1. Ajoutez "--disable-host-check" aux options de lancement dans package.json');
    console.log('2. Utilisez "ionic serve --external --address=0.0.0.0 --disable-host-check"');
}

const startBothPath = path.join(__dirname, 'start-both.bat');
if (fs.existsSync(startBothPath)) {
    try {
        let content = fs.readFileSync(startBothPath, 'utf8');
        
        if (!content.includes('--disable-host-check')) {
            content = content.replace(
                /ionic serve --external --address=0.0.0.0/g, 
                'ionic serve --external --address=0.0.0.0 --disable-host-check'
            );
            fs.writeFileSync(startBothPath, content, 'utf8');
            console.log('✅ Option --disable-host-check ajoutée à start-both.bat');
        }
    } catch (error) {
        console.error('❌ Erreur lors de la modification de start-both.bat:', error);
    }
} 