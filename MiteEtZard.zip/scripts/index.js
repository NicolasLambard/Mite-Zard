console.log('Script exécuté avec succès');

module.exports = {
  run: () => {
    console.log('Fonction run() exécutée');
  }
}; 