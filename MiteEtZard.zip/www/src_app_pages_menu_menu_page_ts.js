"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_menu_menu_page_ts"],{

/***/ 8777:
/*!*****************************************!*\
  !*** ./src/app/pages/menu/menu.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MenuPage: () => (/* binding */ MenuPage)
/* harmony export */ });
/* harmony import */ var F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9204);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 5312);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var src_app_components_menu_composet_menu_composet_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/menu-composet/menu-composet.component */ 3909);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var src_app_cart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/cart.service */ 2431);

var _MenuPage;









function MenuPage_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "ion-spinner", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Chargement du menu...");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function MenuPage_ion_card_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-card", 8)(1, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "ion-button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MenuPage_ion_card_6_Template_ion_button_click_3_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r1.loadMenu());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "R\u00E9essayer");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r1.error, " ");
  }
}
function MenuPage_div_7_div_1_ion_col_5_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "img", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", item_r4.image_data, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"])("alt", item_r4.nom_produit);
  }
}
function MenuPage_div_7_div_1_ion_col_5_p_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r4.description);
  }
}
function MenuPage_div_7_div_1_ion_col_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-col", 13)(1, "ion-card")(2, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, MenuPage_div_7_div_1_ion_col_5_div_3_Template, 2, 2, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 16)(5, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, MenuPage_div_7_div_1_ion_col_5_p_7_Template, 2, 1, "p", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "p", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "ion-button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MenuPage_div_7_div_1_ion_col_5_Template_ion_button_click_10_listener() {
      const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r3).$implicit;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r1.addToCart(item_r4));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "ion-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, " Ajouter au panier ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", item_r4.image_data);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r4.nom_produit);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", item_r4.description);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.formatPrice(item_r4.prix));
  }
}
function MenuPage_div_7_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 11)(1, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "ion-grid")(4, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, MenuPage_div_7_div_1_ion_col_5_Template, 13, 4, "ion-col", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const category_r5 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](category_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r1.menuItems[category_r5]);
  }
}
function MenuPage_div_7_ion_card_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-content")(2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Aucun produit n'est actuellement disponible au menu.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
}
function MenuPage_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, MenuPage_div_7_div_1_Template, 6, 2, "div", 10)(2, MenuPage_div_7_ion_card_2_Template, 4, 0, "ion-card", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r1.categories);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.categories.length === 0);
  }
}
class MenuPage {
  constructor(http, cartService, toastCtrl) {
    this.http = http;
    this.cartService = cartService;
    this.toastCtrl = toastCtrl;
    this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.apiUrl;
    this.loading = true;
    this.error = null;
    this.menuItems = {};
    this.categories = [];
  }
  ngOnInit() {
    this.loadMenu();
  }
  loadMenu() {
    this.loading = true;
    this.error = null;
    this.http.get(`${this.apiUrl}/menu`).subscribe(response => {
      this.menuItems = response;
      this.categories = Object.keys(response);
      this.loading = false;
    }, error => {
      console.error('Error loading menu:', error);
      this.error = 'Impossible de charger le menu. Veuillez réessayer.';
      this.loading = false;
    });
  }
  formatPrice(price) {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    }).format(price);
  }
  addToCart(product) {
    this.cartService.addProductToCart(product);
    this.showToast(`${product.nom_produit} ajouté au panier`);
  }
  showToast(message) {
    var _this = this;
    return (0,F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toastCtrl.create({
        message: message,
        duration: 2000,
        position: 'bottom',
        color: 'success'
      });
      toast.present();
    })();
  }
}
_MenuPage = MenuPage;
_MenuPage.ɵfac = function MenuPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _MenuPage)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_cart_service__WEBPACK_IMPORTED_MODULE_3__.CartService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController));
};
_MenuPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: _MenuPage,
  selectors: [["app-menu"]],
  decls: 10,
  vars: 3,
  consts: [["color", "primary"], [1, "ion-padding"], ["class", "loading-container", 4, "ngIf"], ["color", "danger", 4, "ngIf"], [4, "ngIf"], [1, "section-divider"], [1, "loading-container"], ["name", "crescent"], ["color", "danger"], ["expand", "block", 3, "click"], ["class", "category-section", 4, "ngFor", "ngForOf"], [1, "category-section"], ["size", "12", "size-md", "6", 4, "ngFor", "ngForOf"], ["size", "12", "size-md", "6"], [1, "card-content"], ["class", "product-image", 4, "ngIf"], [1, "product-info"], [1, "price"], ["name", "cart-outline", "slot", "start"], [1, "product-image"], [3, "src", "alt"]],
  template: function MenuPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Menu");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-content", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, MenuPage_div_5_Template, 4, 0, "div", 2)(6, MenuPage_ion_card_6_Template, 5, 1, "ion-card", 3)(7, MenuPage_div_7_Template, 3, 2, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "div", 5)(9, "app-menu-composet");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.loading);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.error);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.loading && !ctx.error);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonSpinner, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonToolbar, src_app_components_menu_composet_menu_composet_component__WEBPACK_IMPORTED_MODULE_2__.MenuComposetComponent],
  styles: ["@charset \"UTF-8\";\n.menu-container[_ngcontent-%COMP%] {\n  padding: 12px;\n  background-color: #121212;\n}\n\nion-grid[_ngcontent-%COMP%] {\n  padding: 8px;\n}\n\nion-row[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n}\n\nion-col[_ngcontent-%COMP%] {\n  padding: 6px;\n}\n\n.burger-card[_ngcontent-%COMP%] {\n  background: #1e1e1e;\n  border-radius: 12px;\n  margin: 0;\n  overflow: hidden;\n  transition: transform 0.2s ease, box-shadow 0.2s ease;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n  min-height: 210px;\n}\n.burger-card[_ngcontent-%COMP%]:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);\n}\n.burger-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  padding: 10px;\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  flex-shrink: 0;\n}\n.burger-card[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  color: #fff;\n  font-weight: 600;\n  line-height: 1.2;\n  margin: 0;\n  min-height: 2.4em;\n}\n\n.burger-price[_ngcontent-%COMP%] {\n  color: #ffa726;\n  font-size: 0.85rem;\n  font-weight: 600;\n  margin: 0;\n}\n\n.burger-image[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 130px;\n  object-fit: cover;\n}\n\n\n\nion-back-button[_ngcontent-%COMP%] {\n  --color: white;\n  --icon-margin-end: 4px;\n  --icon-font-size: 16px;\n}\n\n\n\n@media (min-width: 768px) {\n  .menu-container[_ngcontent-%COMP%] {\n    padding: 16px;\n  }\n  ion-col[_ngcontent-%COMP%] {\n    padding: 8px;\n  }\n  .burger-card[_ngcontent-%COMP%] {\n    border-radius: 14px;\n    min-height: 240px;\n  }\n  .burger-image[_ngcontent-%COMP%] {\n    height: 150px;\n  }\n  ion-card-title[_ngcontent-%COMP%] {\n    font-size: 1.05rem;\n  }\n  ion-card-header[_ngcontent-%COMP%] {\n    padding: 12px;\n  }\n}\n.loading-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  height: 200px;\n}\n.loading-container[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin-top: 16px;\n  color: var(--ion-color-medium);\n}\n\n.category-section[_ngcontent-%COMP%] {\n  margin-bottom: 24px;\n}\n.category-section[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 1.8rem;\n  font-weight: 600;\n  margin-bottom: 16px;\n  padding-bottom: 8px;\n  border-bottom: 2px solid var(--ion-color-primary);\n  color: var(--ion-color-dark);\n}\n\nion-card[_ngcontent-%COMP%] {\n  margin: 10px 0;\n  border-radius: 12px;\n  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n  overflow: hidden;\n}\nion-card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: row;\n  height: 100%;\n}\n@media (max-width: 576px) {\n  ion-card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%] {\n    flex-direction: column;\n  }\n}\nion-card[_ngcontent-%COMP%]   .product-image[_ngcontent-%COMP%] {\n  width: 120px;\n  height: 120px;\n  flex-shrink: 0;\n}\n@media (max-width: 576px) {\n  ion-card[_ngcontent-%COMP%]   .product-image[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 160px;\n  }\n}\nion-card[_ngcontent-%COMP%]   .product-image[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\nion-card[_ngcontent-%COMP%]   .product-info[_ngcontent-%COMP%] {\n  padding: 16px;\n  flex-grow: 1;\n  display: flex;\n  flex-direction: column;\n}\nion-card[_ngcontent-%COMP%]   .product-info[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-size: 1.2rem;\n  font-weight: 600;\n  margin: 0 0 8px 0;\n  color: var(--ion-color-dark);\n}\nion-card[_ngcontent-%COMP%]   .product-info[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  color: var(--ion-color-medium);\n  margin: 0 0 8px 0;\n}\nion-card[_ngcontent-%COMP%]   .product-info[_ngcontent-%COMP%]   .price[_ngcontent-%COMP%] {\n  margin-top: auto;\n  font-weight: 700;\n  font-size: 1.2rem;\n  color: var(--ion-color-primary);\n}\n\n@media (min-width: 768px) {\n  ion-grid[_ngcontent-%COMP%] {\n    max-width: 1200px;\n    margin: 0 auto;\n  }\n  ion-card[_ngcontent-%COMP%] {\n    height: 100%;\n  }\n  ion-card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%] {\n    height: 100%;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uLy4uLy4uLyU1Qk1JVEVFVFpBUkQlNUQvTWl0ZUV0WmFyZE5ldy9zcmMvYXBwL3BhZ2VzL21lbnUvbWVudS5wYWdlLnNjc3MiLCJ3ZWJwYWNrOi8vLi9zcmMvYXBwL3BhZ2VzL21lbnUvbWVudS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQWhCO0VBQ0UsYUFBQTtFQUNBLHlCQUFBO0FERUY7O0FDQ0E7RUFDRSxZQUFBO0FERUY7O0FDQ0E7RUFDRSxtQkFBQTtBREVGOztBQ0NBO0VBQ0UsWUFBQTtBREVGOztBQ0NBO0VBQ0UsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLHFEQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHdDQUFBO0VBQ0EsaUJBQUE7QURFRjtBQ0FFO0VBQ0UsMkJBQUE7RUFDQSx5Q0FBQTtBREVKO0FDQ0U7RUFDRSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsUUFBQTtFQUNBLGNBQUE7QURDSjtBQ0VFO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtBREFKOztBQ0lBO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0FEREY7O0FDSUE7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FEREY7O0FDSUEsb0NBQUE7QUFDQTtFQUNFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLHNCQUFBO0FEREY7O0FDSUEsdUNBQUE7QUFDQTtFQUNFO0lBQ0UsYUFBQTtFRERGO0VDSUE7SUFDRSxZQUFBO0VERkY7RUNLQTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7RURIRjtFQ01BO0lBQ0UsYUFBQTtFREpGO0VDT0E7SUFDRSxrQkFBQTtFRExGO0VDUUE7SUFDRSxhQUFBO0VETkY7QUFDRjtBQ1NBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7QURQRjtBQ1NFO0VBQ0UsZ0JBQUE7RUFDQSw4QkFBQTtBRFBKOztBQ1dBO0VBQ0UsbUJBQUE7QURSRjtBQ1VFO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxpREFBQTtFQUNBLDRCQUFBO0FEUko7O0FDWUE7RUFDRSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSx3Q0FBQTtFQUNBLGdCQUFBO0FEVEY7QUNXRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QURUSjtBQ1dJO0VBTEY7SUFNSSxzQkFBQTtFRFJKO0FBQ0Y7QUNXRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBRFRKO0FDV0k7RUFMRjtJQU1JLFdBQUE7SUFDQSxhQUFBO0VEUko7QUFDRjtBQ1VJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBRFJOO0FDWUU7RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtBRFZKO0FDWUk7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSw0QkFBQTtBRFZOO0FDYUk7RUFDRSxpQkFBQTtFQUNBLDhCQUFBO0VBQ0EsaUJBQUE7QURYTjtBQ2NJO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsK0JBQUE7QURaTjs7QUNrQkE7RUFDRTtJQUNFLGlCQUFBO0lBQ0EsY0FBQTtFRGZGO0VDa0JBO0lBQ0UsWUFBQTtFRGhCRjtFQ2tCRTtJQUNFLFlBQUE7RURoQko7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbi5tZW51LWNvbnRhaW5lciB7XG4gIHBhZGRpbmc6IDEycHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICMxMjEyMTI7XG59XG5cbmlvbi1ncmlkIHtcbiAgcGFkZGluZzogOHB4O1xufVxuXG5pb24tcm93IHtcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcbn1cblxuaW9uLWNvbCB7XG4gIHBhZGRpbmc6IDZweDtcbn1cblxuLmJ1cmdlci1jYXJkIHtcbiAgYmFja2dyb3VuZDogIzFlMWUxZTtcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcbiAgbWFyZ2luOiAwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4ycyBlYXNlLCBib3gtc2hhZG93IDAuMnMgZWFzZTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xuICBtaW4taGVpZ2h0OiAyMTBweDtcbn1cbi5idXJnZXItY2FyZDpob3ZlciB7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtM3B4KTtcbiAgYm94LXNoYWRvdzogMCA2cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMyk7XG59XG4uYnVyZ2VyLWNhcmQgaW9uLWNhcmQtaGVhZGVyIHtcbiAgcGFkZGluZzogMTBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgZ2FwOiA0cHg7XG4gIGZsZXgtc2hyaW5rOiAwO1xufVxuLmJ1cmdlci1jYXJkIGlvbi1jYXJkLXRpdGxlIHtcbiAgZm9udC1zaXplOiAwLjlyZW07XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXdlaWdodDogNjAwO1xuICBsaW5lLWhlaWdodDogMS4yO1xuICBtYXJnaW46IDA7XG4gIG1pbi1oZWlnaHQ6IDIuNGVtO1xufVxuXG4uYnVyZ2VyLXByaWNlIHtcbiAgY29sb3I6ICNmZmE3MjY7XG4gIGZvbnQtc2l6ZTogMC44NXJlbTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbWFyZ2luOiAwO1xufVxuXG4uYnVyZ2VyLWltYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTMwcHg7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xufVxuXG4vKiBTdHlsZXMgcG91ciBsZSBib3V0b24gZGUgcmV0b3VyICovXG5pb24tYmFjay1idXR0b24ge1xuICAtLWNvbG9yOiB3aGl0ZTtcbiAgLS1pY29uLW1hcmdpbi1lbmQ6IDRweDtcbiAgLS1pY29uLWZvbnQtc2l6ZTogMTZweDtcbn1cblxuLyogUmVzcG9uc2l2ZSBwb3VyIMODwqljcmFucyBwbHVzIGdyYW5kcyAqL1xuQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XG4gIC5tZW51LWNvbnRhaW5lciB7XG4gICAgcGFkZGluZzogMTZweDtcbiAgfVxuICBpb24tY29sIHtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLmJ1cmdlci1jYXJkIHtcbiAgICBib3JkZXItcmFkaXVzOiAxNHB4O1xuICAgIG1pbi1oZWlnaHQ6IDI0MHB4O1xuICB9XG4gIC5idXJnZXItaW1hZ2Uge1xuICAgIGhlaWdodDogMTUwcHg7XG4gIH1cbiAgaW9uLWNhcmQtdGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMS4wNXJlbTtcbiAgfVxuICBpb24tY2FyZC1oZWFkZXIge1xuICAgIHBhZGRpbmc6IDEycHg7XG4gIH1cbn1cbi5sb2FkaW5nLWNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBoZWlnaHQ6IDIwMHB4O1xufVxuLmxvYWRpbmctY29udGFpbmVyIHAge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG59XG5cbi5jYXRlZ29yeS1zZWN0aW9uIHtcbiAgbWFyZ2luLWJvdHRvbTogMjRweDtcbn1cbi5jYXRlZ29yeS1zZWN0aW9uIGgyIHtcbiAgZm9udC1zaXplOiAxLjhyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gIHBhZGRpbmctYm90dG9tOiA4cHg7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG5cbmlvbi1jYXJkIHtcbiAgbWFyZ2luOiAxMHB4IDA7XG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gIGJveC1zaGFkb3c6IDAgNHB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5pb24tY2FyZCAuY2FyZC1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgaGVpZ2h0OiAxMDAlO1xufVxuQG1lZGlhIChtYXgtd2lkdGg6IDU3NnB4KSB7XG4gIGlvbi1jYXJkIC5jYXJkLWNvbnRlbnQge1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIH1cbn1cbmlvbi1jYXJkIC5wcm9kdWN0LWltYWdlIHtcbiAgd2lkdGg6IDEyMHB4O1xuICBoZWlnaHQ6IDEyMHB4O1xuICBmbGV4LXNocmluazogMDtcbn1cbkBtZWRpYSAobWF4LXdpZHRoOiA1NzZweCkge1xuICBpb24tY2FyZCAucHJvZHVjdC1pbWFnZSB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxNjBweDtcbiAgfVxufVxuaW9uLWNhcmQgLnByb2R1Y3QtaW1hZ2UgaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG5pb24tY2FyZCAucHJvZHVjdC1pbmZvIHtcbiAgcGFkZGluZzogMTZweDtcbiAgZmxleC1ncm93OiAxO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuaW9uLWNhcmQgLnByb2R1Y3QtaW5mbyBoMyB7XG4gIGZvbnQtc2l6ZTogMS4ycmVtO1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW46IDAgMCA4cHggMDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbn1cbmlvbi1jYXJkIC5wcm9kdWN0LWluZm8gcCB7XG4gIGZvbnQtc2l6ZTogMC45cmVtO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIG1hcmdpbjogMCAwIDhweCAwO1xufVxuaW9uLWNhcmQgLnByb2R1Y3QtaW5mbyAucHJpY2Uge1xuICBtYXJnaW4tdG9wOiBhdXRvO1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LXNpemU6IDEuMnJlbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XG4gIGlvbi1ncmlkIHtcbiAgICBtYXgtd2lkdGg6IDEyMDBweDtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgfVxuICBpb24tY2FyZCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICB9XG4gIGlvbi1jYXJkIC5jYXJkLWNvbnRlbnQge1xuICAgIGhlaWdodDogMTAwJTtcbiAgfVxufSIsIi5tZW51LWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZzogMTJweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTIxMjEyO1xyXG59XHJcblxyXG5pb24tZ3JpZCB7XHJcbiAgcGFkZGluZzogOHB4O1xyXG59XHJcblxyXG5pb24tcm93IHtcclxuICBtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG59XHJcblxyXG5pb24tY29sIHtcclxuICBwYWRkaW5nOiA2cHg7XHJcbn1cclxuXHJcbi5idXJnZXItY2FyZCB7XHJcbiAgYmFja2dyb3VuZDogIzFlMWUxZTtcclxuICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gIG1hcmdpbjogMDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjJzIGVhc2UsIGJveC1zaGFkb3cgMC4ycyBlYXNlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYm94LXNoYWRvdzogMCA0cHggOHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICBtaW4taGVpZ2h0OiAyMTBweDtcclxuXHJcbiAgJjpob3ZlciB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTNweCk7XHJcbiAgICBib3gtc2hhZG93OiAwIDZweCAxMnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICB9XHJcblxyXG4gIGlvbi1jYXJkLWhlYWRlciB7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBnYXA6IDRweDtcclxuICAgIGZsZXgtc2hyaW5rOiAwO1xyXG4gIH1cclxuXHJcbiAgaW9uLWNhcmQtdGl0bGUge1xyXG4gICAgZm9udC1zaXplOiAwLjlyZW07XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBsaW5lLWhlaWdodDogMS4yO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgbWluLWhlaWdodDogMi40ZW07XHJcbiAgfVxyXG59XHJcblxyXG4uYnVyZ2VyLXByaWNlIHtcclxuICBjb2xvcjogI2ZmYTcyNjtcclxuICBmb250LXNpemU6IDAuODVyZW07XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi5idXJnZXItaW1hZ2Uge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTMwcHg7XHJcbiAgb2JqZWN0LWZpdDogY292ZXI7XHJcbn1cclxuXHJcbi8qIFN0eWxlcyBwb3VyIGxlIGJvdXRvbiBkZSByZXRvdXIgKi9cclxuaW9uLWJhY2stYnV0dG9uIHtcclxuICAtLWNvbG9yOiB3aGl0ZTtcclxuICAtLWljb24tbWFyZ2luLWVuZDogNHB4O1xyXG4gIC0taWNvbi1mb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbi8qIFJlc3BvbnNpdmUgcG91ciDDg8KpY3JhbnMgcGx1cyBncmFuZHMgKi9cclxuQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XHJcbiAgLm1lbnUtY29udGFpbmVyIHtcclxuICAgIHBhZGRpbmc6IDE2cHg7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1jb2wge1xyXG4gICAgcGFkZGluZzogOHB4O1xyXG4gIH1cclxuICBcclxuICAuYnVyZ2VyLWNhcmQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgIG1pbi1oZWlnaHQ6IDI0MHB4O1xyXG4gIH1cclxuICBcclxuICAuYnVyZ2VyLWltYWdlIHtcclxuICAgIGhlaWdodDogMTUwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1jYXJkLXRpdGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMS4wNXJlbTtcclxuICB9XHJcbiAgXHJcbiAgaW9uLWNhcmQtaGVhZGVyIHtcclxuICAgIHBhZGRpbmc6IDEycHg7XHJcbiAgfVxyXG59XHJcblxyXG4ubG9hZGluZy1jb250YWluZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGhlaWdodDogMjAwcHg7XHJcbiAgXHJcbiAgcCB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gIH1cclxufVxyXG5cclxuLmNhdGVnb3J5LXNlY3Rpb24ge1xyXG4gIG1hcmdpbi1ib3R0b206IDI0cHg7XHJcbiAgXHJcbiAgaDIge1xyXG4gICAgZm9udC1zaXplOiAxLjhyZW07XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA4cHg7XHJcbiAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICB9XHJcbn1cclxuXHJcbmlvbi1jYXJkIHtcclxuICBtYXJnaW46IDEwcHggMDtcclxuICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gIGJveC1zaGFkb3c6IDAgNHB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICBcclxuICAuY2FyZC1jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgXHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNTc2cHgpIHtcclxuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIH1cclxuICB9XHJcbiAgXHJcbiAgLnByb2R1Y3QtaW1hZ2Uge1xyXG4gICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgaGVpZ2h0OiAxMjBweDtcclxuICAgIGZsZXgtc2hyaW5rOiAwO1xyXG4gICAgXHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNTc2cHgpIHtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIGhlaWdodDogMTYwcHg7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAucHJvZHVjdC1pbmZvIHtcclxuICAgIHBhZGRpbmc6IDE2cHg7XHJcbiAgICBmbGV4LWdyb3c6IDE7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIFxyXG4gICAgaDMge1xyXG4gICAgICBmb250LXNpemU6IDEuMnJlbTtcclxuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgbWFyZ2luOiAwIDAgOHB4IDA7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIHAge1xyXG4gICAgICBmb250LXNpemU6IDAuOXJlbTtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgICBtYXJnaW46IDAgMCA4cHggMDtcclxuICAgIH1cclxuICAgIFxyXG4gICAgLnByaWNlIHtcclxuICAgICAgbWFyZ2luLXRvcDogYXV0bztcclxuICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgZm9udC1zaXplOiAxLjJyZW07XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4vLyBTdHlsZXMgcG91ciDDg8KpY3JhbnMgcGx1cyBncmFuZHNcclxuQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XHJcbiAgaW9uLWdyaWQge1xyXG4gICAgbWF4LXdpZHRoOiAxMjAwcHg7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICB9XHJcbiAgXHJcbiAgaW9uLWNhcmQge1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgXHJcbiAgICAuY2FyZC1jb250ZW50IHtcclxuICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgfVxyXG4gIH1cclxufSJdLCJzb3VyY2VSb290IjoiIn0= */", ".section-divider[_ngcontent-%COMP%] {\n  height: 2px;\n  background-color: var(--ion-color-light);\n  margin: 30px 0;\n}\n\n.product-info[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvbWVudS9tZW51LnBhZ2UuaHRtbCIsIndlYnBhY2s6Ly8uLy4uLy4uLyU1Qk1JVEVFVFpBUkQlNUQvTWl0ZUV0WmFyZE5ldy9zcmMvYXBwL3BhZ2VzL21lbnUvbWVudS5wYWdlLmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxXQUFBO0VBQ0Esd0NBQUE7RUFDQSxjQUFBO0FDQUo7O0FER0U7RUFDRSxnQkFBQTtBQ0FKIiwic291cmNlc0NvbnRlbnQiOlsiXG4gIC5zZWN0aW9uLWRpdmlkZXIge1xuICAgIGhlaWdodDogMnB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gICAgbWFyZ2luOiAzMHB4IDA7XG4gIH1cbiAgXG4gIC5wcm9kdWN0LWluZm8gaW9uLWJ1dHRvbiB7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgfVxuIiwiLnNlY3Rpb24tZGl2aWRlciB7XG4gIGhlaWdodDogMnB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICBtYXJnaW46IDMwcHggMDtcbn1cblxuLnByb2R1Y3QtaW5mbyBpb24tYnV0dG9uIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_menu_menu_page_ts.js.map