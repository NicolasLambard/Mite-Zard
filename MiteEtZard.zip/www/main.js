(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 1854:
/*!********************************!*\
  !*** ./src/app/admin.guard.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AdminGuard: () => (/* binding */ AdminGuard)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 4334);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 271);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 671);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 5072);
var _AdminGuard;




class AdminGuard {
  constructor(authService, router) {
    this.authService = authService;
    this.router = router;
  }
  canActivate(route, state) {
    return this.authService.isAdmin().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(isAdmin => {
      if (!isAdmin) {
        console.log('Accès refusé: droits administrateur requis');
        this.router.navigate(['/accueil']);
        return false;
      }
      return true;
    }));
  }
}
_AdminGuard = AdminGuard;
_AdminGuard.ɵfac = function AdminGuard_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AdminGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
};
_AdminGuard.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _AdminGuard,
  factory: _AdminGuard.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 9564:
/*!**********************************!*\
  !*** ./src/app/admin.service.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AdminService: () => (/* binding */ AdminService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../environments/environment */ 5312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.service */ 671);
var _AdminService;





class AdminService {
  constructor(http, authService) {
    this.http = http;
    this.authService = authService;
    this.apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl;
  }
  // Méthode privée pour obtenir les en-têtes avec le token
  getHeaders() {
    const token = this.authService.getToken();
    if (!token) {
      console.error('❌ Pas de token d\'authentification trouvé');
    } else {
      console.log('✅ Token trouvé:', token.substring(0, 20) + '...');
    }
    return new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }
  // Méthodes pour les catégories
  getAllCategories() {
    console.log('📋 Récupération des catégories...');
    return this.http.get(`${this.apiUrl}/admin/categories`, {
      headers: this.getHeaders()
    });
  }
  createCategory(categoryData) {
    console.log('➕ Création d\'une nouvelle catégorie:', categoryData);
    return this.http.post(`${this.apiUrl}/admin/categories`, categoryData, {
      headers: this.getHeaders()
    });
  }
  updateCategory(categoryData) {
    console.log('🔄 Mise à jour de la catégorie:', categoryData);
    return this.http.put(`${this.apiUrl}/admin/categories/${categoryData.id_categorie}`, categoryData, {
      headers: this.getHeaders()
    });
  }
  deleteCategory(categoryId) {
    console.log('🗑️ Suppression de la catégorie:', categoryId);
    return this.http.delete(`${this.apiUrl}/admin/categories/${categoryId}`, {
      headers: this.getHeaders()
    });
  }
  // Méthodes pour les produits
  getAllProducts() {
    console.log('📋 Récupération des produits...');
    return this.http.get(`${this.apiUrl}/admin/products`, {
      headers: this.getHeaders()
    });
  }
  createProduct(productData) {
    console.log('➕ Création d\'un nouveau produit');
    const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
      'Authorization': `Bearer ${this.authService.getToken()}`
    });
    // Ne pas définir Content-Type, il sera automatiquement défini avec le boundary pour FormData
    return this.http.post(`${this.apiUrl}/admin/products`, productData, {
      headers
    });
  }
  updateProduct(productData) {
    console.log('🔄 Mise à jour du produit');
    const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
      'Authorization': `Bearer ${this.authService.getToken()}`
    });
    // Ne pas définir Content-Type, il sera automatiquement défini avec le boundary pour FormData
    return this.http.put(`${this.apiUrl}/admin/products`, productData, {
      headers
    });
  }
  deleteProduct(productId) {
    console.log('🗑️ Suppression du produit:', productId);
    return this.http.delete(`${this.apiUrl}/admin/products/${productId}`, {
      headers: this.getHeaders()
    });
  }
  toggleProductStatus(productId, newStatus) {
    console.log('🔄 Changement du statut du produit:', {
      productId,
      newStatus
    });
    return this.http.put(`${this.apiUrl}/admin/products/toggle-status`, {
      id_produit: productId,
      actif: newStatus
    }, {
      headers: this.getHeaders()
    });
  }
  // Méthode pour obtenir l'ID de l'utilisateur courant
  getCurrentUserId() {
    return this.authService.getCurrentUserId();
  }
  // Méthodes pour les utilisateurs
  getAllUsers() {
    return this.http.get(`${this.apiUrl}/admin/users`, {
      headers: this.getHeaders()
    });
  }
  updateUserRole(userId, roleId) {
    return this.http.put(`${this.apiUrl}/admin/users/${userId}/role`, {
      roleId
    }, {
      headers: this.getHeaders()
    });
  }
  // Méthode pour vérifier la configuration des rôles
  checkRoleConfig() {
    console.log('🔍 Vérification de la configuration des rôles...');
    return this.http.get(`${this.apiUrl}/admin/check-roles`, {
      headers: this.getHeaders()
    });
  }
  // Méthode pour initialiser les tables de rôles
  initRoles() {
    console.log('🔧 Initialisation des rôles...');
    return this.http.post(`${this.apiUrl}/admin/init-roles`, {}, {
      headers: this.getHeaders()
    });
  }
  // Méthode pour attribuer le rôle admin à l'utilisateur actuel
  assignAdminRole() {
    console.log('🔑 Attribution du rôle admin...');
    return this.http.post(`${this.apiUrl}/admin/assign-admin`, {}, {
      headers: this.getHeaders()
    });
  }
}
_AdminService = AdminService;
_AdminService.ɵfac = function AdminService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AdminService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService));
};
_AdminService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _AdminService,
  factory: _AdminService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 4114:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRoutingModule: () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _admin_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin.guard */ 1854);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
var _AppRoutingModule;




const routes = [{
  path: '',
  redirectTo: 'login',
  pathMatch: 'full'
}, {
  path: 'login',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/login/login.module */ 9370)).then(m => m.LoginPageModule)
}, {
  path: 'inscription',
  loadComponent: () => __webpack_require__.e(/*! import() */ "src_app_pages_inscription_inscription_page_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/inscription/inscription.page */ 8113)).then(m => m.InscriptionPage)
}, {
  path: 'menu',
  loadComponent: () => __webpack_require__.e(/*! import() */ "src_app_pages_menu_menu_page_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/menu/menu.page */ 8777)).then(m => m.MenuPage)
}, {
  path: 'profile',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_profile_profile_page_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/profile/profile.page */ 3901)).then(m => m.ProfilePage)
}, {
  path: 'accueil',
  loadComponent: () => __webpack_require__.e(/*! import() */ "src_app_pages_accueil_accueil_page_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/accueil/accueil.page */ 6841)).then(m => m.AccueilPage)
}, {
  path: 'cart',
  loadComponent: () => __webpack_require__.e(/*! import() */ "src_app_pages_cart_cart_page_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/cart/cart.page */ 2731)).then(m => m.CartPage)
}, {
  path: 'admin',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_admin_admin_page_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/admin/admin.page */ 25)).then(m => m.AdminPage),
  canActivate: [_admin_guard__WEBPACK_IMPORTED_MODULE_0__.AdminGuard]
}, {
  path: 'admin/produits',
  loadComponent: () => __webpack_require__.e(/*! import() */ "src_app_pages_admin_produits_produits_page_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/admin/produits/produits.page */ 1955)).then(m => m.ProduitsPage),
  canActivate: [_admin_guard__WEBPACK_IMPORTED_MODULE_0__.AdminGuard]
}, {
  path: 'admin/categories',
  loadComponent: () => __webpack_require__.e(/*! import() */ "src_app_pages_admin_categories_categories_page_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/admin/categories/categories.page */ 3143)).then(m => m.CategoriesPage),
  canActivate: [_admin_guard__WEBPACK_IMPORTED_MODULE_0__.AdminGuard]
}, {
  path: 'admin/users',
  loadComponent: () => __webpack_require__.e(/*! import() */ "src_app_pages_admin_users_users_page_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/admin/users/users.page */ 6861)).then(m => m.UsersPage),
  canActivate: [_admin_guard__WEBPACK_IMPORTED_MODULE_0__.AdminGuard]
}, {
  path: 'admin/orders',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_admin_orders_orders_page_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/admin/orders/orders.page */ 3429)).then(m => m.OrdersPage),
  canActivate: [_admin_guard__WEBPACK_IMPORTED_MODULE_0__.AdminGuard]
}, {
  path: '**',
  redirectTo: 'login'
}];
class AppRoutingModule {}
_AppRoutingModule = AppRoutingModule;
_AppRoutingModule.ɵfac = function AppRoutingModule_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AppRoutingModule)();
};
_AppRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
  type: _AppRoutingModule
});
_AppRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes), _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
});
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
  });
})();

/***/ }),

/***/ 92:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 671);
/* harmony import */ var _admin_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admin.service */ 9564);
/* harmony import */ var _cart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cart.service */ 2431);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 316);
var _AppComponent;







function AppComponent_ion_fab_2_ion_badge_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-badge", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r1.cartItemCount);
  }
}
function AppComponent_ion_fab_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-fab", 1)(1, "ion-fab-button", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function AppComponent_ion_fab_2_Template_ion_fab_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r1.goToCart());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, AppComponent_ion_fab_2_ion_badge_3_Template, 2, 1, "ion-badge", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.cartItemCount > 0);
  }
}
class AppComponent {
  constructor(router, menuCtrl, authService, adminService, cartService) {
    this.router = router;
    this.menuCtrl = menuCtrl;
    this.authService = authService;
    this.adminService = adminService;
    this.cartService = cartService;
    this.cartItemCount = 0;
    this.showCartButton = true;
  }
  ngOnInit() {
    // Vérifier la session actuelle
    if (this.authService.isLoggedIn()) {
      console.log('✅ Utilisateur déjà connecté');
      this.authService.chargerRolesUtilisateur();
      // Vérifier si l'utilisateur est admin
      this.authService.isAdmin().subscribe(isAdmin => {
        if (isAdmin) {
          console.log('🛡️ Utilisateur avec rôle administrateur détecté');
          // Vérifier la configuration des rôles
          this.adminService.checkRoleConfig().subscribe(result => {
            console.log('📊 Statut des rôles:', result);
          }, error => {
            console.error('❌ Erreur lors de la vérification des rôles:', error);
            if (error.status === 500) {
              console.log('🔧 Tentative d\'initialisation des rôles...');
              this.adminService.initRoles().subscribe(result => console.log('✅ Initialisation des rôles réussie:', result), err => console.error('❌ Échec de l\'initialisation des rôles:', err));
            }
          });
        }
      });
    }
    // Observer le nombre d'articles dans le panier
    this.cartService.cartItems$.subscribe(items => {
      this.cartItemCount = this.cartService.getItemCount();
    });
    // Observer les changements de route pour cacher le bouton sur certaines pages
    this.router.events.subscribe(() => {
      const currentUrl = this.router.url;
      // Cacher le bouton sur les pages de login, inscription, panier et admin
      this.showCartButton = !currentUrl.includes('/login') && !currentUrl.includes('/inscription') && !currentUrl.includes('/cart') && !currentUrl.includes('/admin');
    });
  }
  /**
   * Navigate to a specific route
   * @param route The route to navigate to
   */
  navigateTo(route) {
    console.log(`🔀 Navigation vers ${route}`);
    this.router.navigate([`/${route}`]);
    this.menuCtrl.close(); // Ferme le menu après navigation
  }
  /**
   * Log out and navigate to the login page
   */
  logout() {
    console.log('🔒 Déconnexion en cours...');
    this.authService.logout();
    this.router.navigate(['/login']);
    this.menuCtrl.close(); // Ferme le menu après déconnexion
  }
  goToCart() {
    this.router.navigate(['/cart']);
  }
}
_AppComponent = AppComponent;
_AppComponent.ɵfac = function AppComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_admin_service__WEBPACK_IMPORTED_MODULE_1__.AdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_cart_service__WEBPACK_IMPORTED_MODULE_2__.CartService));
};
_AppComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: _AppComponent,
  selectors: [["app-root"]],
  standalone: false,
  decls: 3,
  vars: 1,
  consts: [["vertical", "bottom", "horizontal", "end", "slot", "fixed", 4, "ngIf"], ["vertical", "bottom", "horizontal", "end", "slot", "fixed"], [3, "click"], ["name", "cart-outline"], ["color", "danger", 4, "ngIf"], ["color", "danger"]],
  template: function AppComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-app");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "ion-router-outlet");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, AppComponent_ion_fab_2_Template, 4, 1, "ion-fab", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.showCartButton);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonApp, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonFab, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonFabButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRouterOutlet],
  styles: ["ion-fab[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n  margin-right: 20px;\n}\n\nion-fab-button[_ngcontent-%COMP%] {\n  --box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);\n}\n\nion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  border-radius: 50%;\n  font-size: 12px;\n  --padding-start: 5px;\n  --padding-end: 5px;\n  --padding-top: 3px;\n  --padding-bottom: 3px;\n  min-width: 18px;\n  height: 18px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwid2VicGFjazovLy4vLi4vLi4vJTVCTUlURUVUWkFSRCU1RC9NaXRlRXRaYXJkTmV3L3NyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsbUJBQUE7RUFDQSxrQkFBQTtBQ0FGOztBREdBO0VBQ0UsMkNBQUE7QUNBRjs7QURHQTtFQUNFLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLFFBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNBRiIsInNvdXJjZXNDb250ZW50IjpbIi8vIFN0eWxlIHBvdXIgbGUgYm91dG9uIGR1IHBhbmllclxyXG5pb24tZmFiIHtcclxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjBweDtcclxufVxyXG5cclxuaW9uLWZhYi1idXR0b24ge1xyXG4gIC0tYm94LXNoYWRvdzogMCA0cHggMTBweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbn1cclxuXHJcbmlvbi1iYWRnZSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMDtcclxuICByaWdodDogMDtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIC0tcGFkZGluZy1zdGFydDogNXB4O1xyXG4gIC0tcGFkZGluZy1lbmQ6IDVweDtcclxuICAtLXBhZGRpbmctdG9wOiAzcHg7XHJcbiAgLS1wYWRkaW5nLWJvdHRvbTogM3B4O1xyXG4gIG1pbi13aWR0aDogMThweDtcclxuICBoZWlnaHQ6IDE4cHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcbiIsImlvbi1mYWIge1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1ib3gtc2hhZG93OiAwIDRweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcbn1cblxuaW9uLWJhZGdlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIHJpZ2h0OiAwO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA1cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDVweDtcbiAgLS1wYWRkaW5nLXRvcDogM3B4O1xuICAtLXBhZGRpbmctYm90dG9tOiAzcHg7XG4gIG1pbi13aWR0aDogMThweDtcbiAgaGVpZ2h0OiAxOHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
});

/***/ }),

/***/ 635:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppModule: () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 436);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 92);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 4114);
/* harmony import */ var _components_menu_composet_menu_composet_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/menu-composet/menu-composet.component */ 3909);
/* harmony import */ var _interceptors_auth_interceptor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./interceptors/auth.interceptor */ 472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);
var _AppModule;







// Intercepteur pour ajouter le token d'authentification



class AppModule {}
_AppModule = AppModule;
_AppModule.ɵfac = function AppModule_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AppModule)();
};
_AppModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
  type: _AppModule,
  bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent]
});
_AppModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
  providers: [{
    provide: _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouteReuseStrategy,
    useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicRouteStrategy
  }, {
    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HTTP_INTERCEPTORS,
    useClass: _interceptors_auth_interceptor__WEBPACK_IMPORTED_MODULE_3__.AuthInterceptor,
    multi: true
  }],
  imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule, _components_menu_composet_menu_composet_component__WEBPACK_IMPORTED_MODULE_2__.MenuComposetComponent]
});
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule, _components_menu_composet_menu_composet_component__WEBPACK_IMPORTED_MODULE_2__.MenuComposetComponent]
  });
})();

/***/ }),

/***/ 671:
/*!*********************************!*\
  !*** ./src/app/auth.service.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthService: () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 9452);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 8764);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 1318);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 271);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../environments/environment */ 5312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 5072);
var _AuthService;






class AuthService {
  constructor(http, router) {
    this.http = http;
    this.router = router;
    this.apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl;
    this.utilisateurSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this.utilisateur$ = this.utilisateurSubject.asObservable();
    this.rolesSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
    this.roles$ = this.rolesSubject.asObservable();
    this.isAdminSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
    this.isAdmin$ = this.isAdminSubject.asObservable();
    this.chargerUtilisateur();
  }
  // Charger l'utilisateur depuis le stockage local
  chargerUtilisateur() {
    const userData = localStorage.getItem('utilisateur');
    if (userData) {
      const user = JSON.parse(userData);
      this.utilisateurSubject.next(user);
      // Charger les rôles et le statut admin si disponibles
      const rolesData = localStorage.getItem('roles');
      if (rolesData) {
        const roles = JSON.parse(rolesData);
        this.rolesSubject.next(roles);
        this.isAdminSubject.next(roles.includes('Administrateur'));
      } else {
        // Si pas de rôles stockés, mais un utilisateur existe, récupérer les rôles
        this.chargerRolesUtilisateur();
      }
    }
  }
  // Récupérer les rôles de l'utilisateur depuis l'API
  chargerRolesUtilisateur(userId) {
    // Si userId n'est pas fourni, utiliser l'ID de l'utilisateur courant
    const id = userId || this.getCurrentUserId();
    if (!id) {
      console.error('❌ Impossible de charger les rôles: aucun ID utilisateur disponible');
      return;
    }
    this.http.get(`${this.apiUrl}/users/roles?userId=${id}`).subscribe(response => {
      if (response && response.roles) {
        const roles = response.roles.split(',').map(role => role.trim());
        this.rolesSubject.next(roles);
        this.isAdminSubject.next(roles.includes('Administrateur'));
        localStorage.setItem('roles', JSON.stringify(roles));
      }
    }, error => {
      console.error('Erreur lors du chargement des rôles:', error);
    });
  }
  // Connexion de l'utilisateur
  login(email, motDePasse) {
    return this.http.post(`${this.apiUrl}/users/login`, {
      email,
      motDePasse
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      console.log('Réponse de connexion:', response);
      if (response && response.utilisateur) {
        // Sauvegarde du token JWT
        if (response.token) {
          localStorage.setItem('token', response.token);
          console.log('✅ Token JWT sauvegardé');
        }
        // Sauvegarde de l'utilisateur
        this.utilisateurSubject.next(response.utilisateur);
        localStorage.setItem('utilisateur', JSON.stringify(response.utilisateur));
        localStorage.setItem('userEmail', response.utilisateur.email); // Pour compatibilité
        // Sauvegarde des rôles
        if (response.roles) {
          const roles = response.roles.split(',').map(role => role.trim());
          this.rolesSubject.next(roles);
          this.isAdminSubject.next(response.isAdmin === true);
          localStorage.setItem('roles', JSON.stringify(roles));
        }
        // Rediriger après la connexion réussie
        setTimeout(() => {
          this.router.navigate(['/accueil']);
        }, 300);
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      var _error$error;
      console.error('Erreur de connexion:', error);
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({
        success: false,
        message: ((_error$error = error.error) === null || _error$error === void 0 ? void 0 : _error$error.message) || 'Une erreur est survenue lors de la connexion'
      });
    }));
  }
  // Déconnexion de l'utilisateur
  logout() {
    localStorage.removeItem('utilisateur');
    localStorage.removeItem('roles');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('token'); // Supprimer le token JWT
    this.utilisateurSubject.next(null);
    this.rolesSubject.next([]);
    this.isAdminSubject.next(false);
    this.router.navigate(['/login']);
  }
  // Vérifier si l'utilisateur est connecté
  isLoggedIn() {
    return !!this.utilisateurSubject.value;
  }
  // Vérifier si l'utilisateur est authentifié (alias de isLoggedIn pour plus de clarté)
  isAuthenticated() {
    return this.isLoggedIn();
  }
  // Obtenir l'ID de l'utilisateur actuel
  getCurrentUserId() {
    const user = this.utilisateurSubject.value;
    console.log('Utilisateur actuel depuis BehaviorSubject:', user);
    if (!user) {
      // Si pas d'utilisateur dans le BehaviorSubject, essayer de le récupérer depuis localStorage
      const storedUser = localStorage.getItem('utilisateur');
      console.log('Utilisateur stocké en localStorage:', storedUser);
      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser);
          console.log('Utilisateur parsé depuis localStorage:', parsedUser);
          return parsedUser.id;
        } catch (e) {
          console.error('Erreur lors du parsing de l\'utilisateur:', e);
          return null;
        }
      }
      return null;
    }
    return user.id;
  }
  // Vérifier si l'utilisateur a un rôle spécifique
  hasRole(role) {
    return this.roles$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(roles => roles.includes(role)));
  }
  // Vérifier si l'utilisateur est admin
  isAdmin() {
    return this.isAdmin$;
  }
  // Vérifier si l'utilisateur est gérant
  isGerant() {
    return this.hasRole('Gérant');
  }
  // Méthode pour obtenir le token
  getToken() {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('❌ Pas de token JWT trouvé dans le localStorage');
      return null;
    }
    return token;
  }
}
_AuthService = AuthService;
_AuthService.ɵfac = function AuthService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router));
};
_AuthService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjectable"]({
  token: _AuthService,
  factory: _AuthService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 2431:
/*!*********************************!*\
  !*** ./src/app/cart.service.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CartService: () => (/* binding */ CartService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
var _CartService;


class CartService {
  constructor() {
    this.cartItemsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject([]);
    this.cartItems$ = this.cartItemsSubject.asObservable();
    this.loadCartFromStorage();
  }
  // Charger le panier depuis le stockage local
  loadCartFromStorage() {
    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
      try {
        const cartItems = JSON.parse(storedCart);
        this.cartItemsSubject.next(cartItems);
      } catch (error) {
        console.error('Erreur lors du chargement du panier:', error);
        this.cartItemsSubject.next([]);
      }
    }
  }
  // Sauvegarder le panier dans le stockage local
  saveCartToStorage() {
    const cartItems = this.cartItemsSubject.value;
    localStorage.setItem('cart', JSON.stringify(cartItems));
  }
  // Ajouter un produit au panier
  addProductToCart(product) {
    const cartItems = [...this.cartItemsSubject.value];
    const existingItemIndex = cartItems.findIndex(item => item.id === product.id_produit && item.type === 'product');
    if (existingItemIndex !== -1) {
      // Augmenter la quantité si le produit existe déjà
      cartItems[existingItemIndex].quantity += 1;
    } else {
      // Ajouter un nouveau produit
      cartItems.push({
        id: product.id_produit,
        type: 'product',
        name: product.nom_produit,
        price: parseFloat(product.prix),
        quantity: 1,
        image: product.image_data
      });
    }
    this.cartItemsSubject.next(cartItems);
    this.saveCartToStorage();
  }
  // Ajouter un menu au panier
  addMenuToCart(menu) {
    const cartItems = [...this.cartItemsSubject.value];
    const existingItemIndex = cartItems.findIndex(item => item.id === menu.id_menu && item.type === 'menu');
    if (existingItemIndex !== -1) {
      // Augmenter la quantité si le menu existe déjà
      cartItems[existingItemIndex].quantity += 1;
    } else {
      // Ajouter un nouveau menu
      cartItems.push({
        id: menu.id_menu,
        type: 'menu',
        name: menu.nom_menu,
        price: parseFloat(menu.prix),
        quantity: 1,
        image: menu.image_data,
        details: {
          produits: menu.produits
        }
      });
    }
    this.cartItemsSubject.next(cartItems);
    this.saveCartToStorage();
  }
  // Mettre à jour la quantité d'un article
  updateItemQuantity(itemIndex, quantity) {
    if (quantity <= 0) {
      this.removeItem(itemIndex);
      return;
    }
    const cartItems = [...this.cartItemsSubject.value];
    if (itemIndex >= 0 && itemIndex < cartItems.length) {
      cartItems[itemIndex].quantity = quantity;
      this.cartItemsSubject.next(cartItems);
      this.saveCartToStorage();
    }
  }
  // Supprimer un article du panier
  removeItem(itemIndex) {
    const cartItems = [...this.cartItemsSubject.value];
    if (itemIndex >= 0 && itemIndex < cartItems.length) {
      cartItems.splice(itemIndex, 1);
      this.cartItemsSubject.next(cartItems);
      this.saveCartToStorage();
    }
  }
  // Vider le panier
  clearCart() {
    this.cartItemsSubject.next([]);
    this.saveCartToStorage();
  }
  // Obtenir le nombre total d'articles dans le panier
  getItemCount() {
    return this.cartItemsSubject.value.reduce((count, item) => count + item.quantity, 0);
  }
  // Obtenir le montant total du panier
  getTotalAmount() {
    return this.cartItemsSubject.value.reduce((total, item) => total + item.price * item.quantity, 0);
  }
  // Obtenir les articles du panier
  getCartItems() {
    return this.cartItemsSubject.value;
  }
}
_CartService = CartService;
_CartService.ɵfac = function CartService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CartService)();
};
_CartService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
  token: _CartService,
  factory: _CartService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 3909:
/*!*********************************************************************!*\
  !*** ./src/app/components/menu-composet/menu-composet.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MenuComposetComponent: () => (/* binding */ MenuComposetComponent)
/* harmony export */ });
/* harmony import */ var F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 5312);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var src_app_cart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/cart.service */ 2431);
/* harmony import */ var src_app_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth.service */ 671);

var _MenuComposetComponent;









const _c0 = a0 => [a0, "EUR", "symbol", "1.2-2", "fr"];
function MenuComposetComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "ion-spinner", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Chargement des menus compos\u00E9s...");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function MenuComposetComponent_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "ion-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Pas de menus compos\u00E9s disponibles");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Vous pouvez commander des produits individuels en attendant.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function MenuComposetComponent_ion_grid_8_ion_col_2_img_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "img", 23);
  }
  if (rf & 2) {
    const menu_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("alt", menu_r2.nom_menu);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", menu_r2.image_data, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
  }
}
function MenuComposetComponent_ion_grid_8_ion_col_2_img_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "img", 24);
  }
}
function MenuComposetComponent_ion_grid_8_ion_col_2_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const menu_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" -", ctx_r2.calculateDiscount(menu_r2), "% ");
  }
}
function MenuComposetComponent_ion_grid_8_ion_col_2_span_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const menu_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBindV"](2, 1, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](7, _c0, ctx_r2.calculateOriginalPrice(menu_r2))), " ");
  }
}
function MenuComposetComponent_ion_grid_8_ion_col_2_ion_item_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-item");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "ion-icon", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const produit_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](produit_r4.nom_produit);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBindV"](6, 2, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](8, _c0, produit_r4.prix)));
  }
}
function MenuComposetComponent_ion_grid_8_ion_col_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-col", 10)(1, "ion-card")(2, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, MenuComposetComponent_ion_grid_8_ion_col_2_img_3_Template, 1, 2, "img", 12)(4, MenuComposetComponent_ion_grid_8_ion_col_2_img_4_Template, 1, 0, "img", 13)(5, MenuComposetComponent_ion_grid_8_ion_col_2_div_5_Template, 2, 1, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "ion-card-header")(7, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "ion-card-subtitle")(10, "div", 15)(11, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](13, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, MenuComposetComponent_ion_grid_8_ion_col_2_span_14_Template, 3, 9, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "ion-card-content")(16, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "ion-list", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, MenuComposetComponent_ion_grid_8_ion_col_2_ion_item_19_Template, 7, 10, "ion-item", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "ion-button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MenuComposetComponent_ion_grid_8_ion_col_2_Template_ion_button_click_20_listener() {
      const menu_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r1).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r2.addToCart(menu_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](21, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, " Ajouter au panier ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const menu_r2 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", menu_r2.image_data);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !menu_r2.image_data);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r2.calculateDiscount(menu_r2) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](menu_r2.nom_menu);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBindV"](13, 8, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](14, _c0, menu_r2.prix)));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r2.calculateDiscount(menu_r2) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](menu_r2.description);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", menu_r2.produits);
  }
}
function MenuComposetComponent_ion_grid_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, MenuComposetComponent_ion_grid_8_ion_col_2_Template, 23, 16, "ion-col", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r2.menus);
  }
}
class MenuComposetComponent {
  constructor(http, cartService, toastCtrl, alertController, authService) {
    this.http = http;
    this.cartService = cartService;
    this.toastCtrl = toastCtrl;
    this.alertController = alertController;
    this.authService = authService;
    this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.apiUrl;
    this.menus = [];
    this.loading = true;
  }
  ngOnInit() {
    console.log('🔄 Initialisation du composant MenuComposet');
    this.loadMenus();
  }
  loadMenus() {
    var _this = this;
    return (0,F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('📥 Début du chargement des menus');
      _this.loading = true;
      try {
        const response = yield _this.http.get(`${_this.apiUrl}/menus`).toPromise();
        console.log('✅ Réponse reçue du serveur:', response);
        if (response && Array.isArray(response)) {
          _this.menus = response;
          console.log(`📋 ${_this.menus.length} menus chargés`);
        } else {
          console.warn('⚠️ La réponse n\'est pas un tableau:', response);
          _this.menus = [];
        }
      } catch (error) {
        console.error('❌ Erreur lors du chargement des menus:', error);
        _this.showError('Impossible de charger les menus.');
        _this.menus = [];
      } finally {
        _this.loading = false;
      }
    })();
  }
  calculateOriginalPrice(menu) {
    if (!menu.produits || menu.produits.length === 0) {
      return menu.prix;
    }
    // Calculer le prix total des produits individuels
    return menu.produits.reduce((total, produit) => {
      return total + parseFloat(produit.prix);
    }, 0);
  }
  calculateDiscount(menu) {
    const originalPrice = this.calculateOriginalPrice(menu);
    if (originalPrice <= menu.prix) {
      return 0;
    }
    // Calculer le pourcentage de réduction
    const discount = (originalPrice - menu.prix) / originalPrice * 100;
    return Math.round(discount);
  }
  addToCart(menu) {
    try {
      this.cartService.addMenuToCart(menu);
      this.showToast(`${menu.nom_menu} ajouté au panier`);
    } catch (error) {
      console.error('Erreur lors de l\'ajout au panier:', error);
      this.showError('Impossible d\'ajouter le menu au panier.');
    }
  }
  showError(message) {
    var _this2 = this;
    return (0,F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this2.toastCtrl.create({
        message,
        duration: 3000,
        position: 'bottom',
        color: 'danger'
      });
      toast.present();
    })();
  }
  showToast(message) {
    var _this3 = this;
    return (0,F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this3.toastCtrl.create({
        message,
        duration: 2000,
        position: 'bottom',
        color: 'success'
      });
      toast.present();
    })();
  }
  creerMenuTest() {
    var _this4 = this;
    return (0,F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        // Vérifier si l'utilisateur est admin
        const userId = _this4.authService.getCurrentUserId();
        if (!userId) {
          _this4.showError('Vous devez être connecté pour effectuer cette action.');
          return;
        }
        _this4.loading = true;
        // Récupérer les produits disponibles
        const produits = yield _this4.http.get(`${_this4.apiUrl}/produits/actifs`).toPromise();
        if (!produits || produits.length < 2) {
          _this4.showError('Il faut au moins 2 produits pour créer un menu.');
          _this4.loading = false;
          return;
        }
        // Sélectionner 2 produits pour créer un menu
        const produitsMenu = produits.slice(0, 2).map(p => p.id_produit);
        // Calculer un prix légèrement réduit par rapport à la somme des produits
        const prixTotal = produits.slice(0, 2).reduce((sum, p) => sum + parseFloat(p.prix), 0);
        const prixMenu = (prixTotal * 0.9).toFixed(2); // 10% de réduction
        // Créer le menu
        const menuData = new FormData();
        menuData.append('userId', userId.toString());
        menuData.append('nom_menu', 'Menu Test');
        menuData.append('description', 'Menu créé automatiquement pour test');
        menuData.append('prix', prixMenu.toString());
        menuData.append('produits', JSON.stringify(produitsMenu));
        menuData.append('actif', '1');
        const response = yield _this4.http.post(`${_this4.apiUrl}/admin/menus`, menuData).toPromise();
        _this4.showToast('Menu créé avec succès !');
        // Attendre un court instant puis recharger les menus pour s'assurer que les données sont à jour
        setTimeout(() => {
          _this4.loadMenus();
        }, 500);
      } catch (error) {
        console.error('Erreur lors de la création du menu test:', error);
        _this4.showError('Impossible de créer le menu test. Vérifiez vos droits administrateur.');
      } finally {
        _this4.loading = false;
      }
    })();
  }
}
_MenuComposetComponent = MenuComposetComponent;
_MenuComposetComponent.ɵfac = function MenuComposetComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _MenuComposetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_cart_service__WEBPACK_IMPORTED_MODULE_2__.CartService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService));
};
_MenuComposetComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: _MenuComposetComponent,
  selectors: [["app-menu-composet"]],
  decls: 9,
  vars: 3,
  consts: [[1, "menus-container"], [1, "section-title"], ["class", "loading-container", 4, "ngIf"], ["class", "empty-state-card", 4, "ngIf"], [4, "ngIf"], [1, "loading-container"], ["name", "crescent"], [1, "empty-state-card"], ["name", "restaurant-outline", "size", "large"], ["size", "12", "size-md", "6", "size-lg", "4", 4, "ngFor", "ngForOf"], ["size", "12", "size-md", "6", "size-lg", "4"], [1, "menu-image-container"], ["class", "menu-image", 3, "src", "alt", 4, "ngIf"], ["src", "assets/images/menu-default.jpg", "alt", "Image par d\u00E9faut", "class", "menu-image", 4, "ngIf"], ["class", "menu-discount", 4, "ngIf"], [1, "price-container"], [1, "current-price"], ["class", "original-price", 4, "ngIf"], [1, "menu-description"], ["lines", "none", 1, "menu-products-list"], [4, "ngFor", "ngForOf"], ["expand", "block", "color", "success", 1, "add-to-cart-btn", 3, "click"], ["name", "cart-outline", "slot", "start"], [1, "menu-image", 3, "src", "alt"], ["src", "assets/images/menu-default.jpg", "alt", "Image par d\u00E9faut", 1, "menu-image"], [1, "menu-discount"], [1, "original-price"], ["name", "checkmark-circle-outline", "slot", "start"], ["slot", "end"]],
  template: function MenuComposetComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Nos Menus Compos\u00E9s");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "D\u00E9couvrez nos formules de menus \u00E0 prix avantageux, incluant plusieurs produits");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, MenuComposetComponent_div_6_Template, 4, 0, "div", 2)(7, MenuComposetComponent_div_7_Template, 6, 0, "div", 3)(8, MenuComposetComponent_ion_grid_8_Template, 3, 1, "ion-grid", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.loading);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.loading && (!ctx.menus || ctx.menus.length === 0));
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.loading && ctx.menus && ctx.menus.length > 0);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.CurrencyPipe, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardSubtitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonList, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonSpinner],
  styles: [".menu-container[_ngcontent-%COMP%] {\n  padding: 16px;\n}\n\n.menu-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 16px;\n}\n\n.menu-title[_ngcontent-%COMP%] {\n  font-size: 1.5rem;\n  font-weight: bold;\n  color: var(--ion-color-primary);\n}\n\n.menu-content[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));\n  gap: 16px;\n}\n\n.menu-item[_ngcontent-%COMP%] {\n  background: var(--ion-color-light);\n  border-radius: 8px;\n  overflow: hidden;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  transition: transform 0.2s ease;\n}\n.menu-item[_ngcontent-%COMP%]:hover {\n  transform: translateY(-2px);\n}\n\n.menu-item-image[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 200px;\n  object-fit: cover;\n}\n\n.menu-item-content[_ngcontent-%COMP%] {\n  padding: 12px;\n}\n\n.menu-item-title[_ngcontent-%COMP%] {\n  font-size: 1.1rem;\n  font-weight: 600;\n  margin-bottom: 8px;\n}\n\n.menu-item-description[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  color: var(--ion-color-medium);\n  margin-bottom: 8px;\n}\n\n.menu-item-price[_ngcontent-%COMP%] {\n  font-size: 1.2rem;\n  font-weight: bold;\n  color: var(--ion-color-primary);\n}\n\n.menu-item-actions[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 8px;\n}\n\n.menu-category[_ngcontent-%COMP%] {\n  margin-bottom: 24px;\n}\n\n.category-title[_ngcontent-%COMP%] {\n  font-size: 1.3rem;\n  font-weight: 600;\n  color: var(--ion-color-dark);\n  margin-bottom: 16px;\n  padding-bottom: 8px;\n  border-bottom: 2px solid var(--ion-color-primary);\n}\n\n.loading-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 32px;\n}\n\n.loading-spinner[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n}\n\n.loading-text[_ngcontent-%COMP%] {\n  color: var(--ion-color-medium);\n}\n\n.error-message[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 16px;\n  color: var(--ion-color-danger);\n  background: var(--ion-color-danger-tint);\n  border-radius: 8px;\n  margin: 16px 0;\n}\n\n.action-button[_ngcontent-%COMP%] {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --padding-top: 8px;\n  --padding-bottom: 8px;\n  font-weight: 500;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9tZW51LWNvbXBvc2V0L21lbnUtY29tcG9zZXQuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi8lNUJNSVRFRVRaQVJEJTVEL01pdGVFdFphcmROZXcvc3JjL2FwcC9jb21wb25lbnRzL21lbnUtY29tcG9zZXQvbWVudS1jb21wb3NldC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLGFBQUE7QUNBRjs7QURHQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUNBRjs7QURHQTtFQUNFLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSwrQkFBQTtBQ0FGOztBREdBO0VBQ0UsYUFBQTtFQUNBLDREQUFBO0VBQ0EsU0FBQTtBQ0FGOztBREdBO0VBQ0Usa0NBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esd0NBQUE7RUFDQSwrQkFBQTtBQ0FGO0FERUU7RUFDRSwyQkFBQTtBQ0FKOztBRElBO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtBQ0RGOztBRElBO0VBQ0UsYUFBQTtBQ0RGOztBRElBO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDREY7O0FESUE7RUFDRSxpQkFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7QUNERjs7QURJQTtFQUNFLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSwrQkFBQTtBQ0RGOztBRElBO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0FDREY7O0FESUE7RUFDRSxtQkFBQTtBQ0RGOztBRElBO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLDRCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGlEQUFBO0FDREY7O0FES0E7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtBQ0ZGOztBREtBO0VBQ0UsbUJBQUE7QUNGRjs7QURLQTtFQUNFLDhCQUFBO0FDRkY7O0FETUE7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLHdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDSEY7O0FET0E7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0FDSkYiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBTdHlsZXMgcG91ciBsZSBjb21wb3NhbnQgbWVudS1jb21wb3NldFxyXG4ubWVudS1jb250YWluZXIge1xyXG4gIHBhZGRpbmc6IDE2cHg7XHJcbn1cclxuXHJcbi5tZW51LWhlYWRlciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xyXG59XHJcblxyXG4ubWVudS10aXRsZSB7XHJcbiAgZm9udC1zaXplOiAxLjVyZW07XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxufVxyXG5cclxuLm1lbnUtY29udGVudCB7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpbGwsIG1pbm1heCgyNTBweCwgMWZyKSk7XHJcbiAgZ2FwOiAxNnB4O1xyXG59XHJcblxyXG4ubWVudS1pdGVtIHtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuMnMgZWFzZTtcclxuXHJcbiAgJjpob3ZlciB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTJweCk7XHJcbiAgfVxyXG59XHJcblxyXG4ubWVudS1pdGVtLWltYWdlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDIwMHB4O1xyXG4gIG9iamVjdC1maXQ6IGNvdmVyO1xyXG59XHJcblxyXG4ubWVudS1pdGVtLWNvbnRlbnQge1xyXG4gIHBhZGRpbmc6IDEycHg7XHJcbn1cclxuXHJcbi5tZW51LWl0ZW0tdGl0bGUge1xyXG4gIGZvbnQtc2l6ZTogMS4xcmVtO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xyXG59XHJcblxyXG4ubWVudS1pdGVtLWRlc2NyaXB0aW9uIHtcclxuICBmb250LXNpemU6IDAuOXJlbTtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xyXG59XHJcblxyXG4ubWVudS1pdGVtLXByaWNlIHtcclxuICBmb250LXNpemU6IDEuMnJlbTtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcblxyXG4ubWVudS1pdGVtLWFjdGlvbnMge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgbWFyZ2luLXRvcDogOHB4O1xyXG59XHJcblxyXG4ubWVudS1jYXRlZ29yeSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjRweDtcclxufVxyXG5cclxuLmNhdGVnb3J5LXRpdGxlIHtcclxuICBmb250LXNpemU6IDEuM3JlbTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICBwYWRkaW5nLWJvdHRvbTogOHB4O1xyXG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbn1cclxuXHJcbi8vIFN0eWxlcyBwb3VyIGxlcyDDg8KpdGF0cyBkZSBjaGFyZ2VtZW50XHJcbi5sb2FkaW5nLWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgcGFkZGluZzogMzJweDtcclxufVxyXG5cclxuLmxvYWRpbmctc3Bpbm5lciB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxufVxyXG5cclxuLmxvYWRpbmctdGV4dCB7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG59XHJcblxyXG4vLyBTdHlsZXMgcG91ciBsZXMgbWVzc2FnZXMgZCdlcnJldXJcclxuLmVycm9yLW1lc3NhZ2Uge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwYWRkaW5nOiAxNnB4O1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyLXRpbnQpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICBtYXJnaW46IDE2cHggMDtcclxufVxyXG5cclxuLy8gU3R5bGVzIHBvdXIgbGVzIGJvdXRvbnMgZCdhY3Rpb25cclxuLmFjdGlvbi1idXR0b24ge1xyXG4gIC0tcGFkZGluZy1zdGFydDogMTZweDtcclxuICAtLXBhZGRpbmctZW5kOiAxNnB4O1xyXG4gIC0tcGFkZGluZy10b3A6IDhweDtcclxuICAtLXBhZGRpbmctYm90dG9tOiA4cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxufSAiLCIubWVudS1jb250YWluZXIge1xuICBwYWRkaW5nOiAxNnB4O1xufVxuXG4ubWVudS1oZWFkZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XG59XG5cbi5tZW51LXRpdGxlIHtcbiAgZm9udC1zaXplOiAxLjVyZW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4ubWVudS1jb250ZW50IHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoYXV0by1maWxsLCBtaW5tYXgoMjUwcHgsIDFmcikpO1xuICBnYXA6IDE2cHg7XG59XG5cbi5tZW51LWl0ZW0ge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjJzIGVhc2U7XG59XG4ubWVudS1pdGVtOmhvdmVyIHtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0ycHgpO1xufVxuXG4ubWVudS1pdGVtLWltYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMjAwcHg7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xufVxuXG4ubWVudS1pdGVtLWNvbnRlbnQge1xuICBwYWRkaW5nOiAxMnB4O1xufVxuXG4ubWVudS1pdGVtLXRpdGxlIHtcbiAgZm9udC1zaXplOiAxLjFyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuLm1lbnUtaXRlbS1kZXNjcmlwdGlvbiB7XG4gIGZvbnQtc2l6ZTogMC45cmVtO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuLm1lbnUtaXRlbS1wcmljZSB7XG4gIGZvbnQtc2l6ZTogMS4ycmVtO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuLm1lbnUtaXRlbS1hY3Rpb25zIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tdG9wOiA4cHg7XG59XG5cbi5tZW51LWNhdGVnb3J5IHtcbiAgbWFyZ2luLWJvdHRvbTogMjRweDtcbn1cblxuLmNhdGVnb3J5LXRpdGxlIHtcbiAgZm9udC1zaXplOiAxLjNyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gIHBhZGRpbmctYm90dG9tOiA4cHg7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbi5sb2FkaW5nLWNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBwYWRkaW5nOiAzMnB4O1xufVxuXG4ubG9hZGluZy1zcGlubmVyIHtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cblxuLmxvYWRpbmctdGV4dCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cblxuLmVycm9yLW1lc3NhZ2Uge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDE2cHg7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWRhbmdlci10aW50KTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBtYXJnaW46IDE2cHggMDtcbn1cblxuLmFjdGlvbi1idXR0b24ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tcGFkZGluZy10b3A6IDhweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogOHB4O1xuICBmb250LXdlaWdodDogNTAwO1xufSJdLCJzb3VyY2VSb290IjoiIn0= */", ".menus-container[_ngcontent-%COMP%] {\n  padding: 20px;\n}\n\n.section-title[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 30px;\n}\n\n.section-title[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 2rem;\n  color: var(--ion-color-primary);\n  margin-bottom: 10px;\n}\n\n.section-title[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 1.1rem;\n  color: var(--ion-color-medium);\n}\n\n.loading-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  min-height: 200px;\n}\n\n.empty-state-card[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 40px 20px;\n  margin: 20px;\n  border-radius: 10px;\n  background-color: var(--ion-color-light);\n}\n\n.empty-state-card[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 64px;\n  color: var(--ion-color-medium);\n  margin-bottom: 20px;\n}\n\n.empty-state-card[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 1.5rem;\n  color: var(--ion-color-dark);\n  margin-bottom: 10px;\n}\n\n.empty-state-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: var(--ion-color-medium);\n  font-size: 1.1rem;\n}\n\n.empty-state-card[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  margin-top: 20px;\n}\n\n.menu-image-container[_ngcontent-%COMP%] {\n  position: relative;\n  height: 180px;\n  width: 100%;\n  overflow: hidden;\n}\n\n.menu-image[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n\n.menu-discount[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  background-color: var(--ion-color-success);\n  color: white;\n  padding: 4px 8px;\n  border-radius: 12px;\n  font-size: 0.9rem;\n  font-weight: bold;\n}\n\n.price-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n\n.current-price[_ngcontent-%COMP%] {\n  font-size: 1.5rem;\n  font-weight: bold;\n  color: var(--ion-color-primary);\n}\n\n.original-price[_ngcontent-%COMP%] {\n  margin-left: 10px;\n  font-size: 1rem;\n  text-decoration: line-through;\n  color: var(--ion-color-medium);\n}\n\n.menu-description[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n}\n\n.menu-products-list[_ngcontent-%COMP%] {\n  padding-left: 20px;\n}\n\n.add-to-cart-btn[_ngcontent-%COMP%] {\n  margin-top: auto;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9tZW51LWNvbXBvc2V0L21lbnUtY29tcG9zZXQuY29tcG9uZW50Lmh0bWwiLCJ3ZWJwYWNrOi8vLi8uLi8uLi8lNUJNSVRFRVRaQVJEJTVEL01pdGVFdFphcmROZXcvc3JjL2FwcC9jb21wb25lbnRzL21lbnUtY29tcG9zZXQvbWVudS1jb21wb3NldC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGFBQUE7QUNBSjs7QURHRTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7QUNBSjs7QURHRTtFQUNFLGVBQUE7RUFDQSwrQkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0U7RUFDRSxpQkFBQTtFQUNBLDhCQUFBO0FDQUo7O0FER0U7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7QUNBSjs7QURHRTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSx3Q0FBQTtBQ0FKOztBREdFO0VBQ0UsZUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUNBSjs7QURHRTtFQUNFLGlCQUFBO0VBQ0EsNEJBQUE7RUFDQSxtQkFBQTtBQ0FKOztBREdFO0VBQ0UsOEJBQUE7RUFDQSxpQkFBQTtBQ0FKOztBREdFO0VBQ0UsZ0JBQUE7QUNBSjs7QURHRTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQ0FKOztBREdFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQ0FKOztBREdFO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLDBDQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FDQUo7O0FER0U7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUNBSjs7QURHRTtFQUNFLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSwrQkFBQTtBQ0FKOztBREdFO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSw4QkFBQTtBQ0FKOztBREdFO0VBQ0UsbUJBQUE7QUNBSjs7QURHRTtFQUNFLGtCQUFBO0FDQUo7O0FER0U7RUFDRSxnQkFBQTtBQ0FKIiwic291cmNlc0NvbnRlbnQiOlsiXG4gIC5tZW51cy1jb250YWluZXIge1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gIH1cbiAgXG4gIC5zZWN0aW9uLXRpdGxlIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgfVxuICBcbiAgLnNlY3Rpb24tdGl0bGUgaDIge1xuICAgIGZvbnQtc2l6ZTogMnJlbTtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIH1cbiAgXG4gIC5zZWN0aW9uLXRpdGxlIHAge1xuICAgIGZvbnQtc2l6ZTogMS4xcmVtO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgfVxuICBcbiAgLmxvYWRpbmctY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBtaW4taGVpZ2h0OiAyMDBweDtcbiAgfVxuICBcbiAgLmVtcHR5LXN0YXRlLWNhcmQge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiA0MHB4IDIwcHg7XG4gICAgbWFyZ2luOiAyMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgfVxuICBcbiAgLmVtcHR5LXN0YXRlLWNhcmQgaW9uLWljb24ge1xuICAgIGZvbnQtc2l6ZTogNjRweDtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgfVxuICBcbiAgLmVtcHR5LXN0YXRlLWNhcmQgaDIge1xuICAgIGZvbnQtc2l6ZTogMS41cmVtO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgfVxuICBcbiAgLmVtcHR5LXN0YXRlLWNhcmQgcCB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICAgIGZvbnQtc2l6ZTogMS4xcmVtO1xuICB9XG4gIFxuICAuZW1wdHktc3RhdGUtY2FyZCBpb24tYnV0dG9uIHtcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xuICB9XG4gIFxuICAubWVudS1pbWFnZS1jb250YWluZXIge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBoZWlnaHQ6IDE4MHB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gIH1cbiAgXG4gIC5tZW51LWltYWdlIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG4gIH1cbiAgXG4gIC5tZW51LWRpc2NvdW50IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAxMHB4O1xuICAgIHJpZ2h0OiAxMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgcGFkZGluZzogNHB4IDhweDtcbiAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICAgIGZvbnQtc2l6ZTogMC45cmVtO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB9XG4gIFxuICAucHJpY2UtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIH1cbiAgXG4gIC5jdXJyZW50LXByaWNlIHtcbiAgICBmb250LXNpemU6IDEuNXJlbTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICB9XG4gIFxuICAub3JpZ2luYWwtcHJpY2Uge1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIGZvbnQtc2l6ZTogMXJlbTtcbiAgICB0ZXh0LWRlY29yYXRpb246IGxpbmUtdGhyb3VnaDtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIH1cbiAgXG4gIC5tZW51LWRlc2NyaXB0aW9uIHtcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICB9XG4gIFxuICAubWVudS1wcm9kdWN0cy1saXN0IHtcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIH1cbiAgXG4gIC5hZGQtdG8tY2FydC1idG4ge1xuICAgIG1hcmdpbi10b3A6IGF1dG87XG4gIH1cbiIsIi5tZW51cy1jb250YWluZXIge1xuICBwYWRkaW5nOiAyMHB4O1xufVxuXG4uc2VjdGlvbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbn1cblxuLnNlY3Rpb24tdGl0bGUgaDIge1xuICBmb250LXNpemU6IDJyZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG5cbi5zZWN0aW9uLXRpdGxlIHAge1xuICBmb250LXNpemU6IDEuMXJlbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuXG4ubG9hZGluZy1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgbWluLWhlaWdodDogMjAwcHg7XG59XG5cbi5lbXB0eS1zdGF0ZS1jYXJkIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA0MHB4IDIwcHg7XG4gIG1hcmdpbjogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cblxuLmVtcHR5LXN0YXRlLWNhcmQgaW9uLWljb24ge1xuICBmb250LXNpemU6IDY0cHg7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cblxuLmVtcHR5LXN0YXRlLWNhcmQgaDIge1xuICBmb250LXNpemU6IDEuNXJlbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cblxuLmVtcHR5LXN0YXRlLWNhcmQgcCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgZm9udC1zaXplOiAxLjFyZW07XG59XG5cbi5lbXB0eS1zdGF0ZS1jYXJkIGlvbi1idXR0b24ge1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuXG4ubWVudS1pbWFnZS1jb250YWluZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGhlaWdodDogMTgwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4ubWVudS1pbWFnZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xufVxuXG4ubWVudS1kaXNjb3VudCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAxMHB4O1xuICByaWdodDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MpO1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDRweCA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gIGZvbnQtc2l6ZTogMC45cmVtO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLnByaWNlLWNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5jdXJyZW50LXByaWNlIHtcbiAgZm9udC1zaXplOiAxLjVyZW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4ub3JpZ2luYWwtcHJpY2Uge1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1zaXplOiAxcmVtO1xuICB0ZXh0LWRlY29yYXRpb246IGxpbmUtdGhyb3VnaDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuXG4ubWVudS1kZXNjcmlwdGlvbiB7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbi5tZW51LXByb2R1Y3RzLWxpc3Qge1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG59XG5cbi5hZGQtdG8tY2FydC1idG4ge1xuICBtYXJnaW4tdG9wOiBhdXRvO1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
});

/***/ }),

/***/ 472:
/*!**************************************************!*\
  !*** ./src/app/interceptors/auth.interceptor.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthInterceptor: () => (/* binding */ AuthInterceptor)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../auth.service */ 671);
var _AuthInterceptor;


class AuthInterceptor {
  constructor(authService) {
    this.authService = authService;
  }
  intercept(request, next) {
    // Récupérer le token depuis le service d'authentification
    const token = this.authService.getToken();
    // Si un token existe, l'ajouter à l'en-tête Authorization
    if (token) {
      // Cloner la requête et ajouter l'en-tête d'autorisation
      const authReq = request.clone({
        headers: request.headers.set('Authorization', `Bearer ${token}`)
      });
      // Passer la requête modifiée au gestionnaire suivant
      return next.handle(authReq);
    }
    // Si pas de token, passer la requête originale
    return next.handle(request);
  }
}
_AuthInterceptor = AuthInterceptor;
_AuthInterceptor.ɵfac = function AuthInterceptor_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AuthInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService));
};
_AuthInterceptor.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
  token: _AuthInterceptor,
  factory: _AuthInterceptor.ɵfac
});

/***/ }),

/***/ 5312:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   environment: () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
  production: false,
  apiUrl: 'http://localhost:3000/api'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.

/***/ }),

/***/ 4429:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 436);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 635);


_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.log(err));

/***/ }),

/***/ 8996:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		7518,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		1981,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		1603,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		2273,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		9642,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		2095,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		2335,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		8221,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		7184,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		8759,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		4248,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		9863,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		1769,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		2569,
		"default-node_modules_ionic_core_dist_esm_data-ae11fd43_js",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		6534,
		"default-node_modules_ionic_core_dist_esm_data-ae11fd43_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		5458,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		654,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		6034,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input-password-toggle.entry.js": [
		5196,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input-password-toggle_entry_js"
	],
	"./ion-input.entry.js": [
		761,
		"default-node_modules_ionic_core_dist_esm_input_utils-09c71bc7_js-node_modules_ionic_core_dist-8b8a84",
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		6492,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		9557,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		8353,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		1024,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		9160,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		393,
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-option.entry.js": [
		8442,
		"node_modules_ionic_core_dist_esm_ion-picker-column-option_entry_js"
	],
	"./ion-picker-column.entry.js": [
		3110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column_entry_js"
	],
	"./ion-picker.entry.js": [
		5575,
		"node_modules_ionic_core_dist_esm_ion-picker_entry_js"
	],
	"./ion-popover.entry.js": [
		6772,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		4810,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		4639,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		628,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		852,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		1479,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		4065,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		7971,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		3184,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment-content.entry.js": [
		4312,
		"node_modules_ionic_core_dist_esm_ion-segment-content_entry_js"
	],
	"./ion-segment-view.entry.js": [
		4540,
		"node_modules_ionic_core_dist_esm_ion-segment-view_entry_js"
	],
	"./ion-segment_2.entry.js": [
		469,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select-modal.entry.js": [
		7101,
		"node_modules_ionic_core_dist_esm_ion-select-modal_entry_js"
	],
	"./ion-select_3.entry.js": [
		8471,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-spinner.entry.js": [
		388,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		2392,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		6059,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		5427,
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		198,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		1735,
		"default-node_modules_ionic_core_dist_esm_input_utils-09c71bc7_js-node_modules_ionic_core_dist-8b8a84",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		7510,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5297,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 8996;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 4140:
/*!************************************************************************************************************************************************************!*\
  !*** ./node_modules/@stencil/core/internal/client/ lazy ^\.\/.*\.entry\.js.*$ include: \.entry\.js$ exclude: \.system\.entry\.js$ strict namespace object ***!
  \************************************************************************************************************************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 4140;
module.exports = webpackEmptyAsyncContext;

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4429)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map