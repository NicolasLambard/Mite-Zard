"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_admin_users_users_page_ts"],{

/***/ 6861:
/*!*************************************************!*\
  !*** ./src/app/pages/admin/users/users.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UsersPage: () => (/* binding */ UsersPage)
/* harmony export */ });
/* harmony import */ var F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9204);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../environments/environment */ 5312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../auth.service */ 671);

var _UsersPage;










function UsersPage_ion_spinner_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-spinner", 14);
  }
}
function UsersPage_ion_list_18_ion_item_1_ion_text_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-text", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "(Vous)");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UsersPage_ion_list_18_ion_item_1_ion_chip_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-chip", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "Client");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UsersPage_ion_list_18_ion_item_1_ion_chip_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-chip", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "G\u00E9rant");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UsersPage_ion_list_18_ion_item_1_ion_chip_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-chip", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "Administrateur");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UsersPage_ion_list_18_ion_item_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-item")(1, "ion-avatar", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "ion-label")(4, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, UsersPage_ion_list_18_ion_item_1_ion_text_6_Template, 2, 0, "ion-text", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, UsersPage_ion_list_18_ion_item_1_ion_chip_10_Template, 2, 0, "ion-chip", 18)(11, UsersPage_ion_list_18_ion_item_1_ion_chip_11_Template, 2, 0, "ion-chip", 19)(12, UsersPage_ion_list_18_ion_item_1_ion_chip_12_Template, 2, 0, "ion-chip", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "ion-buttons", 21)(14, "ion-button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsersPage_ion_list_18_ion_item_1_Template_ion_button_click_14_listener() {
      const user_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r1).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.modifierRole(user_r2, 1, "Client"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](15, "ion-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "ion-button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsersPage_ion_list_18_ion_item_1_Template_ion_button_click_16_listener() {
      const user_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r1).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.modifierRole(user_r2, 2, "G\u00E9rant"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](17, "ion-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "ion-button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsersPage_ion_list_18_ion_item_1_Template_ion_button_click_18_listener() {
      const user_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r1).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.modifierRole(user_r2, 3, "Administrateur"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](19, "ion-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const user_r2 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("current-user", user_r2.id === ctx_r2.currentUserId);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", user_r2.id === ctx_r2.currentUserId ? "primary" : "medium");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate2"]("", user_r2.prenom, " ", user_r2.nom, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", user_r2.id === ctx_r2.currentUserId);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](user_r2.email);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.utilisateurARole(user_r2, "Client"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.utilisateurARole(user_r2, "G\u00E9rant"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.utilisateurARole(user_r2, "Administrateur"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r2.utilisateurARole(user_r2, "Client") ? "success" : "medium");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", ctx_r2.utilisateurARole(user_r2, "Client") ? "checkmark-circle-outline" : "add-circle-outline");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r2.utilisateurARole(user_r2, "G\u00E9rant") ? "warning" : "medium");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", ctx_r2.utilisateurARole(user_r2, "G\u00E9rant") ? "checkmark-circle-outline" : "add-circle-outline");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r2.utilisateurARole(user_r2, "Administrateur") ? "primary" : "medium");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", ctx_r2.utilisateurARole(user_r2, "Administrateur") ? "checkmark-circle-outline" : "add-circle-outline");
  }
}
function UsersPage_ion_list_18_ion_item_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-item")(1, "ion-label", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2, " Aucun utilisateur trouv\u00E9. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
}
function UsersPage_ion_list_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-list");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, UsersPage_ion_list_18_ion_item_1_Template, 20, 16, "ion-item", 15)(2, UsersPage_ion_list_18_ion_item_2_Template, 3, 0, "ion-item", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r2.users);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.users.length === 0);
  }
}
class UsersPage {
  constructor(router, http, authService, alertController, toastController) {
    this.router = router;
    this.http = http;
    this.authService = authService;
    this.alertController = alertController;
    this.toastController = toastController;
    this.apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.apiUrl;
    this.users = [];
    this.roles = [{
      id_role: 1,
      nom_role: 'Client'
    }, {
      id_role: 2,
      nom_role: 'Gérant'
    }, {
      id_role: 3,
      nom_role: 'Administrateur'
    }];
    this.isLoading = true;
    this.currentUserId = null;
  }
  ngOnInit() {
    this.currentUserId = this.authService.getCurrentUserId();
    this.chargerUtilisateurs();
  }
  // Charger tous les utilisateurs
  chargerUtilisateurs() {
    this.isLoading = true;
    const userId = this.authService.getCurrentUserId();
    this.http.get(`${this.apiUrl}/admin/users?userId=${userId}`).subscribe(response => {
      this.users = response;
      this.isLoading = false;
    }, error => {
      console.error('Erreur lors du chargement des utilisateurs:', error);
      this.isLoading = false;
      this.afficherToast('Erreur lors du chargement des utilisateurs', 'danger');
    });
  }
  // Vérifier si un utilisateur a un rôle spécifique
  utilisateurARole(user, roleName) {
    if (!user.roles) return false;
    return user.roles.includes(roleName);
  }
  // Modifier le rôle d'un utilisateur
  modifierRole(user, roleId, roleName) {
    var _this = this;
    return (0,F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // Ne pas permettre de modifier le rôle Client pour l'utilisateur lui-même
      if (user.id === _this.currentUserId && roleId === 1) {
        _this.afficherToast('Vous ne pouvez pas supprimer votre propre rôle de client', 'warning');
        return;
      }
      // Ne pas permettre de supprimer le rôle d'administrateur pour soi-même
      if (user.id === _this.currentUserId && roleId === 3 && _this.utilisateurARole(user, 'Administrateur')) {
        _this.afficherToast('Vous ne pouvez pas supprimer votre propre rôle d\'administrateur', 'warning');
        return;
      }
      const userId = _this.authService.getCurrentUserId();
      const action = _this.utilisateurARole(user, roleName) ? 'retirer' : 'ajouter';
      const alert = yield _this.alertController.create({
        header: 'Confirmation',
        message: `Êtes-vous sûr de vouloir ${action} le rôle "${roleName}" à ${user.prenom} ${user.nom} ?`,
        buttons: [{
          text: 'Annuler',
          role: 'cancel'
        }, {
          text: 'Confirmer',
          handler: () => {
            const donnees = {
              userId,
              targetUserId: user.id,
              roleId
            };
            _this.http.put(`${_this.apiUrl}/admin/users/role`, donnees).subscribe(response => {
              _this.afficherToast(`Rôle ${action === 'ajouter' ? 'ajouté' : 'retiré'} avec succès`, 'success');
              _this.chargerUtilisateurs();
            }, error => {
              console.error('Erreur lors de la modification du rôle:', error);
              _this.afficherToast('Erreur lors de la modification du rôle', 'danger');
            });
          }
        }]
      });
      yield alert.present();
    })();
  }
  // Afficher un toast
  afficherToast(message, couleur = 'primary') {
    var _this2 = this;
    return (0,F_MITEETZARD_MiteEtZardNew_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this2.toastController.create({
        message,
        duration: 3000,
        color: couleur,
        position: 'bottom'
      });
      yield toast.present();
    })();
  }
  // Retour à la page admin
  retourAdmin() {
    this.router.navigate(['/admin']);
  }
}
_UsersPage = UsersPage;
_UsersPage.ɵfac = function UsersPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _UsersPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController));
};
_UsersPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: _UsersPage,
  selectors: [["app-users"]],
  decls: 56,
  vars: 3,
  consts: [["color", "primary"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "slot", "icon-only"], ["name", "people-outline"], [1, "users-container"], ["name", "crescent", "class", "spinner-center", 4, "ngIf"], [4, "ngIf"], ["color", "success", "outline", "", "slot", "start"], ["color", "warning", "outline", "", "slot", "start"], ["color", "primary", "outline", "", "slot", "start"], [1, "usage-guide"], ["color", "medium"], ["color", "danger"], ["name", "crescent", 1, "spinner-center"], [3, "current-user", 4, "ngFor", "ngForOf"], ["name", "person-circle-outline", 1, "avatar-icon", 3, "color"], ["color", "primary", 4, "ngIf"], ["color", "success", "outline", "", 4, "ngIf"], ["color", "warning", "outline", "", 4, "ngIf"], ["color", "primary", "outline", "", 4, "ngIf"], ["slot", "end"], ["fill", "clear", 3, "click", "color"], ["slot", "icon-only", 3, "name"], ["color", "success", "outline", ""], ["color", "warning", "outline", ""], ["color", "primary", "outline", ""], [1, "ion-text-center"]],
  template: function UsersPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-buttons", 1)(3, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsersPage_Template_ion_button_click_3_listener() {
        return ctx.retourAdmin();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "ion-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7, " Gestion des Utilisateurs ");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "ion-content")(9, "div", 5)(10, "ion-card")(11, "ion-card-header")(12, "ion-card-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](13, "Liste des utilisateurs");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "ion-card-subtitle");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "ion-card-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, UsersPage_ion_spinner_17_Template, 1, 0, "ion-spinner", 6)(18, UsersPage_ion_list_18_Template, 3, 2, "ion-list", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](19, "ion-card")(20, "ion-card-header")(21, "ion-card-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](22, "Guide des R\u00F4les");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "ion-card-content")(24, "ion-list")(25, "ion-item")(26, "ion-chip", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](27, "Client");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "ion-label")(29, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](30, "Client");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](32, "Utilisateur standard pouvant passer des commandes, voir le menu, etc.");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](33, "ion-item")(34, "ion-chip", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](35, "G\u00E9rant");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "ion-label")(37, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](38, "G\u00E9rant");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](39, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](40, "Peut g\u00E9rer les commandes et a un acc\u00E8s limit\u00E9 au panel d'administration.");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "ion-item")(42, "ion-chip", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](43, "Administrateur");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "ion-label")(45, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](46, "Administrateur");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](47, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](48, "Acc\u00E8s complet \u00E0 toutes les fonctionnalit\u00E9s et aux pages d'administration.");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](49, "div", 11)(50, "p")(51, "ion-text", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](52, "Cliquez sur les ic\u00F4nes \u00E0 c\u00F4t\u00E9 des utilisateurs pour ajouter ou retirer des r\u00F4les.");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](53, "p")(54, "ion-text", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](55, "Attention: Assurez-vous de toujours avoir au moins un administrateur dans le syst\u00E8me.");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.users.length, " utilisateur(s) enregistr\u00E9(s) ");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isLoading);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.isLoading);
    }
  },
  dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardSubtitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonChip, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonList, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonSpinner, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonText, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonToolbar, _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule],
  styles: [".users-container[_ngcontent-%COMP%] {\n  max-width: 1200px;\n  margin: 0 auto;\n  padding: 16px;\n}\n\n.spinner-center[_ngcontent-%COMP%] {\n  display: block;\n  margin: 20px auto;\n}\n\n.current-user[_ngcontent-%COMP%] {\n  --background: rgba(var(--ion-color-primary-rgb), 0.05);\n}\n\n.avatar-icon[_ngcontent-%COMP%] {\n  font-size: 40px;\n  margin: 4px;\n}\n\n.usage-guide[_ngcontent-%COMP%] {\n  margin-top: 16px;\n  padding: 10px;\n  border-top: 1px solid #eee;\n}\n.usage-guide[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin-bottom: 8px;\n  font-size: 0.9em;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvYWRtaW4vdXNlcnMvdXNlcnMucGFnZS5zY3NzIiwid2VicGFjazovLy4vLi4vLi4vJTVCTUlURUVUWkFSRCU1RC9NaXRlRXRaYXJkTmV3L3NyYy9hcHAvcGFnZXMvYWRtaW4vdXNlcnMvdXNlcnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQ0NGOztBREVBO0VBQ0UsY0FBQTtFQUNBLGlCQUFBO0FDQ0Y7O0FERUE7RUFDRSxzREFBQTtBQ0NGOztBREVBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLDBCQUFBO0FDQ0Y7QURDRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7QUNDSiIsInNvdXJjZXNDb250ZW50IjpbIi51c2Vycy1jb250YWluZXIge1xyXG4gIG1heC13aWR0aDogMTIwMHB4O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIHBhZGRpbmc6IDE2cHg7XHJcbn1cclxuXHJcbi5zcGlubmVyLWNlbnRlciB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luOiAyMHB4IGF1dG87XHJcbn1cclxuXHJcbi5jdXJyZW50LXVzZXIge1xyXG4gIC0tYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1yZ2IpLCAwLjA1KTtcclxufVxyXG5cclxuLmF2YXRhci1pY29uIHtcclxuICBmb250LXNpemU6IDQwcHg7XHJcbiAgbWFyZ2luOiA0cHg7XHJcbn1cclxuXHJcbi51c2FnZS1ndWlkZSB7XHJcbiAgbWFyZ2luLXRvcDogMTZweDtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZWVlO1xyXG4gIFxyXG4gIHAge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogOHB4O1xyXG4gICAgZm9udC1zaXplOiAwLjllbTtcclxuICB9XHJcbn0gIiwiLnVzZXJzLWNvbnRhaW5lciB7XG4gIG1heC13aWR0aDogMTIwMHB4O1xuICBtYXJnaW46IDAgYXV0bztcbiAgcGFkZGluZzogMTZweDtcbn1cblxuLnNwaW5uZXItY2VudGVyIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogMjBweCBhdXRvO1xufVxuXG4uY3VycmVudC11c2VyIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMDUpO1xufVxuXG4uYXZhdGFyLWljb24ge1xuICBmb250LXNpemU6IDQwcHg7XG4gIG1hcmdpbjogNHB4O1xufVxuXG4udXNhZ2UtZ3VpZGUge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBwYWRkaW5nOiAxMHB4O1xuICBib3JkZXItdG9wOiAxcHggc29saWQgI2VlZTtcbn1cbi51c2FnZS1ndWlkZSBwIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xuICBmb250LXNpemU6IDAuOWVtO1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_admin_users_users_page_ts.js.map