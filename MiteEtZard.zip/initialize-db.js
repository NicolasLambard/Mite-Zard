const { db } = require('./db');

async function initializeDatabase() {
  console.log('🚀 Démarrage de l\'initialisation de la base de données...');
  
  try {
    const [tablesRole] = await db.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'lambardn_mite' 
      AND table_name = 'Role'
    `);

    if (tablesRole.length === 0) {
      console.log('Création de la table Role...');
      await db.query(`
        CREATE TABLE Role (
          id_role INT PRIMARY KEY AUTO_INCREMENT,
          nom_role VARCHAR(50) NOT NULL
        )
      `);
      console.log('✅ Table Role créée avec succès.');
      
      await db.query(`
        INSERT INTO Role (id_role, nom_role) VALUES
        (1, 'Client'),
        (2, 'Gérant'),
        (3, 'Administrateur')
      `);
      console.log('✅ Rôles de base insérés avec succès.');
    } else {
      console.log('✅ La table Role existe déjà.');
    }

    const [tablesUserRole] = await db.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'lambardn_mite' 
      AND table_name = 'UtilisateurRole'
    `);

    if (tablesUserRole.length === 0) {
      console.log('Création de la table UtilisateurRole...');
      await db.query(`
        CREATE TABLE UtilisateurRole (
          id_utilisateur INT,
          id_role INT,
          PRIMARY KEY (id_utilisateur, id_role),
          FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur),
          FOREIGN KEY (id_role) REFERENCES Role(id_role)
        )
      `);
      console.log('✅ Table UtilisateurRole créée avec succès.');
      
      const [users] = await db.query('SELECT id_utilisateur FROM Utilisateur');
      
      if (users.length > 0) {
        console.log(`Attribution du rôle Client à ${users.length} utilisateurs existants...`);
        
        for (const user of users) {
          await db.query(
            'INSERT INTO UtilisateurRole (id_utilisateur, id_role) VALUES (?, ?)',
            [user.id_utilisateur, 1]
          );
        }
        
        await db.query(
          'INSERT INTO UtilisateurRole (id_utilisateur, id_role) VALUES (?, ?)',
          [users[0].id_utilisateur, 3]
        );
        
        console.log(`✅ Rôle Client attribué à ${users.length} utilisateurs.`);
        console.log(`✅ Utilisateur ID ${users[0].id_utilisateur} défini comme administrateur.`);
      }
    } else {
      console.log('✅ La table UtilisateurRole existe déjà.');
    }

    console.log('🎉 Initialisation de la base de données terminée avec succès !');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erreur lors de l\'initialisation de la base de données:', error);
    process.exit(1);
  }
}

initializeDatabase(); 