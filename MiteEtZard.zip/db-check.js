const mysql = require('mysql2/promise');

async function checkDb() {
  try {
    console.log('Connexion à la base de données...');
    const connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'lambardn_mite'
    });
    
    console.log('Connexion établie, vérification des tables...');
    
    const [tables] = await connection.query('SHOW TABLES');
    console.log('Tables dans la base de données lambardn_mite:');
    tables.forEach(t => console.log('- ' + Object.values(t)[0]));
    
    try {
      const [catColumns] = await connection.query('DESCRIBE Categorie');
      console.log('\nStructure de la table Categorie:');
      catColumns.forEach(col => console.log(`- ${col.Field}: ${col.Type} ${col.Null === 'NO' ? 'NOT NULL' : ''} ${col.Key === 'PRI' ? 'PRIMARY KEY' : ''}`));
    } catch (error) {
      console.log('\nLa table Categorie n\'existe pas');
    }
    
    try {
      const [prodColumns] = await connection.query('DESCRIBE Produit');
      console.log('\nStructure de la table Produit:');
      prodColumns.forEach(col => console.log(`- ${col.Field}: ${col.Type} ${col.Null === 'NO' ? 'NOT NULL' : ''} ${col.Key === 'PRI' ? 'PRIMARY KEY' : ''}`));
    } catch (error) {
      console.log('\nLa table Produit n\'existe pas');
    }
    
    try {
      const [categories] = await connection.query('SELECT * FROM Categorie');
      console.log('\nDonnées dans la table Categorie:');
      if (categories.length === 0) {
        console.log('Aucune catégorie trouvée');
      } else {
        categories.forEach(cat => console.log(`- ID: ${cat.id_categorie}, Nom: ${cat.nom_categorie}, Ordre: ${cat.ordre}`));
      }
    } catch (error) {
      console.log('\nImpossible de récupérer les données de la table Categorie');
    }
    
    await connection.end();
    console.log('\nVérification terminée');
  } catch (error) {
    console.error('Erreur lors de la vérification de la base de données:', error);
  }
}

checkDb(); 